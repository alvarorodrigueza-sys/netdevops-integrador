import time
from datetime import datetime

import pandas as pd
import streamlit as st

from .config import DB_PATH, THRESHOLD_PERCENT
from .database import connection, init_db

st.set_page_config(
    page_title="NetDevOps Control Center",
    page_icon="🛰️",
    layout="wide",
)

init_db()

def query_df(sql, params=()):
    with connection() as con:
        return pd.read_sql_query(sql, con, params=params)

def fmt_rate(value):
    value = float(value or 0)
    units = ["bps", "Kbps", "Mbps", "Gbps"]
    i = 0
    while value >= 1000 and i < len(units) - 1:
        value /= 1000
        i += 1
    return f"{value:.2f} {units[i]}"

def fmt_time(epoch):
    if not epoch:
        return "-"
    return datetime.fromtimestamp(float(epoch)).strftime("%Y-%m-%d %H:%M:%S")

st.title("NetDevOps Control Center")
st.caption(
    "Cisco IOS-XE vía NETCONF/YANG · FortiGate vía REST API · "
    "dispositivos compartidos en modo estrictamente read-only"
)

@st.fragment(run_every="5s")
def live_dashboard():
    devices = query_df("SELECT * FROM devices ORDER BY device")
    states = query_df(
        """
        SELECT * FROM interface_state
        ORDER BY device, interface
        """
    )
    latest = query_df(
        """
        SELECT t.*
        FROM telemetry t
        JOIN (
            SELECT device, interface, MAX(timestamp) AS max_ts
            FROM telemetry
            GROUP BY device, interface
        ) x
          ON t.device=x.device
         AND t.interface=x.interface
         AND t.timestamp=x.max_ts
        ORDER BY t.device, t.interface
        """
    )
    alerts = query_df(
        """
        SELECT * FROM alerts
        ORDER BY opened_at DESC
        LIMIT 100
        """
    )

    online = 0 if devices.empty else int((devices["status"] == "online").sum())
    active_ifaces = 0 if states.empty else int((states["oper_status"] == "up").sum())
    max_util = 0.0 if latest.empty else float(latest["utilization_pct"].max())
    active_alerts = 0 if alerts.empty else int((alerts["status"] == "detected").sum())

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Dispositivos online", f"{online}/{len(devices) if len(devices) else 3}")
    c2.metric("Interfaces UP", active_ifaces)
    c3.metric("Utilización máxima", f"{max_util:.3f}%")
    c4.metric("Alertas activas", active_alerts)

    tabs = st.tabs(["Resumen", "Interfaces", "Telemetría", "Alertas"])

    with tabs[0]:
        st.subheader("Estado de dispositivos")
        if devices.empty:
            st.info("Todavía no hay datos. Ejecuta el collector.")
        else:
            show = devices.copy()
            show["last_seen"] = show["last_seen"].map(fmt_time)
            st.dataframe(
                show[
                    ["device", "hostname", "vendor", "host", "model", "version", "status", "last_seen"]
                ],
                use_container_width=True,
                hide_index=True,
            )

        st.subheader("Utilización actual")
        if latest.empty:
            st.info("Se requieren al menos dos snapshots por interfaz para calcular utilización.")
        else:
            current = latest[
                ["device", "hostname", "interface", "traffic_bps", "utilization_pct",
                 "rx_errors", "tx_errors", "threshold_exceeded"]
            ].copy()
            current["traffic"] = current["traffic_bps"].map(fmt_rate)
            current["utilization_pct"] = current["utilization_pct"].map(lambda x: round(float(x), 4))
            st.dataframe(
                current[
                    ["device", "hostname", "interface", "traffic", "utilization_pct",
                     "rx_errors", "tx_errors", "threshold_exceeded"]
                ],
                use_container_width=True,
                hide_index=True,
            )

    with tabs[1]:
        if states.empty:
            st.info("Sin interfaces registradas todavía.")
        else:
            st.dataframe(
                states[
                    ["device", "interface", "admin_status", "oper_status", "speed_bps",
                     "phys_address", "ip_address", "rx_bytes", "tx_bytes",
                     "rx_errors", "tx_errors"]
                ],
                use_container_width=True,
                hide_index=True,
            )

    with tabs[2]:
        if states.empty:
            st.info("Sin telemetría.")
        else:
            devices_list = sorted(states["device"].unique().tolist())
            selected_device = st.selectbox("Dispositivo", devices_list, key="tele_device")
            iface_list = sorted(
                states.loc[states["device"] == selected_device, "interface"].unique().tolist()
            )
            selected_iface = st.selectbox("Interfaz", iface_list, key="tele_iface")

            history = query_df(
                """
                SELECT timestamp, traffic_bps, utilization_pct
                FROM telemetry
                WHERE device=? AND interface=?
                ORDER BY timestamp DESC
                LIMIT 300
                """,
                (selected_device, selected_iface),
            )
            if history.empty:
                st.info("Todavía no hay suficientes muestras para esta interfaz.")
            else:
                history = history.sort_values("timestamp")
                history["time"] = pd.to_datetime(history["timestamp"], unit="s")
                st.write(f"Umbral configurado: **{THRESHOLD_PERCENT:.0f}%**")
                st.line_chart(
                    history.set_index("time")[["utilization_pct"]],
                    y_label="Utilización (%)",
                )
                st.line_chart(
                    history.set_index("time")[["traffic_bps"]],
                    y_label="Tráfico (bps)",
                )

    with tabs[3]:
        if alerts.empty:
            st.success("No hay alertas registradas.")
        else:
            show = alerts.copy()
            show["opened_at"] = show["opened_at"].map(fmt_time)
            show["closed_at"] = show["closed_at"].map(fmt_time)
            st.dataframe(show, use_container_width=True, hide_index=True)

live_dashboard()

st.caption(f"Base de datos: {DB_PATH}")
